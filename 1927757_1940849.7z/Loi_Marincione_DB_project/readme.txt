Hello! This is Dario Loi's and Davide Marincione's project.
Here's all the files relevant to our project, there's two backups (just one should be enough)
which (we hope) should be suitable created with:
- "Custom" file-format
- UTF8 encoding
- Pre-Data, Data, Post-Data and Blobs toggles asserted in the Data/Objects window

In case the backups don't want to collaborate we've added a copy of all our operations in .txt format.

Furthermore we leave a copy of our codebase with an already compiled .exe along (RUNS ONLY ON Windows!).

We also leave a copy of our documentation, which in case can also be seen at the same link for which you should've
seen the original proposal.

We are really sorry, but the video we did was too heavy (200 mbs circa), thus we weren't able to load it on moodle
(where the maximum upload is of 100 mbs) not even in the .zip form, thus we uploaded it on youtube
(not listed to avoid random people getting in, but if you want to show it in the future for the sake
of this course we grant you the permission to do so) at "https://youtu.be/TUnOIpA4aUQ".

