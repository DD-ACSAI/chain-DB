#include "DBmanager.h"
#include "queries/Procedure.h"
DBcontext DBmanager::context = DBcontext::DIR_TREE;